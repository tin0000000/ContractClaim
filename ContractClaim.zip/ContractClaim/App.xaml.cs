﻿using System.Windows;

namespace ContractClaim
{
    public partial class App : Application
    {
    }
}